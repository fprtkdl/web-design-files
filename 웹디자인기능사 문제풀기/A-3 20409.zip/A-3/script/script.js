// 탭메뉴
const tabTitle = document.querySelectorAll(".tab-title");
console.log(tabTitle);
const contents = document.querySelectorAll(".contents");
console.log(contents);

tabTitle.forEach((item, index) => {
    item.addEventListener("click", (e) => {
        e.preventDefault();

        tabTitle.forEach((content) => {
            content.classList.remove("view-tab");
        })
        contents.forEach((content) => {
            content.classList.remove("view-tab");
        })

        tabTitle[index].classList.add("view-tab");
        contents[index].classList.add("view-tab");
    })
})

// 모달
const notice = document.getElementById("notice");
const noticeFirst = notice.getElementsByTagName("a")[0];

const modal = document.querySelector(".modal-container");
const modalBtn = document.querySelector(".modal-btn");

noticeFirst.addEventListener("click", () => {
    modal.classList.add("view-modal");
})

modalBtn.addEventListener("click", () => {
    modal.classList.remove("view-modal");
})



// 슬라이드
document.addEventListener("DOMContentLoaded", function() {
    let currentSlide = 0;
    const slides = document.querySelectorAll(".slide");
    const totalSlides = slides.length;

    slides[currentSlide].classList.add("active");

    function showNextSlide() {
        slides[currentSlide].classList.remove("active");
        currentSlide = (currentSlide + 1) % totalSlides;
        slides[currentSlide].classList.add("active");
    }

    setInterval(showNextSlide, 3000);
});