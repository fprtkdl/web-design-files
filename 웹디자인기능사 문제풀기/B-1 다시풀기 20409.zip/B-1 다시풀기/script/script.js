const uList = document.querySelector(".notice");
const aList = uList.getElementsByTagName("a")[0];

const modalBtn = document.querySelector(".modal-btn");
const modalCon = document.querySelector(".modal-container");

aList.addEventListener("click", () => {
    modalCon.classList.add("active");
});

modalBtn.addEventListener("click", () => {
    modalCon.classList.remove("active");
});

// 뷰탭
const tabTitle = document.querySelectorAll(".tab-title");
const contents = document.querySelectorAll(".contents");

tabTitle.forEach((item, index) => {
    item.addEventListener("click", (e) => {
        e.preventDefault();
        tabTitle.forEach((content) => {
            content.classList.remove("view-tab");
        });
        contents.forEach((content) => {
            content.classList.remove("view-tab");
        });
        tabTitle[index].classList.add("view-tab");
        contents[index].classList.add("view-tab");
    });
});



