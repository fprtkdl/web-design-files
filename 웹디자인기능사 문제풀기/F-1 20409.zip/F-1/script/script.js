const tabTitle = document.querySelectorAll(".tab-title");
const contents = document.querySelectorAll(".contents");
tabTitle.forEach((item, index) => {
    item.addEventListener("click", (e) => {
        e.preventDefault();
        tabTitle.forEach((content) => {
            content.classList.remove("view-tab");
        });
        contents.forEach((content) => {
            content.classList.remove("view-tab");
        });
        tabTitle[index].classList.add("view-tab");
        contents[index].classList.add("view-tab");
    });
});

const ulList = document.querySelector(".notice");
const aList = ulList.getElementsByTagName("a")[0];

const modalBtn = document.querySelector(".modal-btn");

const modalContainer = document.querySelector(".modal-container");

aList.addEventListener("click", () => {
    modalContainer.classList.add("active")
})
modalBtn.addEventListener("click", () => {
    modalContainer.classList.remove("active")
})


const slides = document.querySelectorAll('.slide');
let currentIndex = 0;

function showNextSlide() {
    slides[currentIndex].classList.remove('active');
    currentIndex = (currentIndex + 1) % slides.length;
    slides[currentIndex].classList.add('active');
}

// 페이지 접속 시 슬라이드 자동 전환 시작
setInterval(showNextSlide, 3000); // 3초마다 슬라이드 변경
