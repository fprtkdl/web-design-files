const slide = document.querySelectorAll(".slide");
let slideCount = 0;

setInterval(() => {
    slide[slideCount].classList.add("slurp-slide");
    slideCount = (slideCount + 1) % slide.length;
    slide[slideCount].classList.remove("slurp-slide");
}, 3000);

const noticeGalleryTitle = document.querySelectorAll(".tab-title");
const noticeGallery = document.querySelectorAll(".tab-contents");

noticeGalleryTitle.forEach((item, index) => {
    item.addEventListener("click", (e) => {
        e.preventDefault();

        noticeGalleryTitle.forEach((content) => {
            content.classList.remove("view-tab");
        });
        noticeGallery.forEach((content) => {
            content.classList.remove("view-contents");
        });

        noticeGalleryTitle[index].classList.add("view-tab");
        noticeGallery[index].classList.add("view-contents");
    });
});

const ulList = document.querySelector(".notice");
const aList = ulList.getElementsByTagName("a")[0];

const modalClose = document.querySelector(".modal-btn");

const modal = document.querySelector(".modal-container");

aList.addEventListener("click", () => {
    modal.classList.add("active");
});

modalClose.addEventListener("click", () => {
    modal.classList.remove("active");
});

