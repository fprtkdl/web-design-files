const slides = document.querySelectorAll('.slide');
let currentIndex = 0;

function showNextSlide() {
    slides[currentIndex].classList.remove('active');
    currentIndex = (currentIndex + 1) % slides.length;
    slides[currentIndex].classList.add('active');
}

// 페이지 접속 시 슬라이드 자동 전환 시작
setInterval(showNextSlide, 3000); // 3초마다 슬라이드 변경




const ulList = document.querySelector(".notice-list");
const aList = ulList.getElementsByTagName("a")[0];

const modalBtn = document.querySelector(".modal-btn");

const modalContainer = document.querySelector(".modal-container");

aList.addEventListener("click", () => {
    modalContainer.classList.add("active")
})
modalBtn.addEventListener("click", () => {
    modalContainer.classList.remove("active")
})
