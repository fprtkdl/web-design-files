const notice = document.querySelector(".notice");
const noticeA = notice.querySelectorAll("a")[0]

const modal = document.querySelector(".modal-container");
const modalBtn = document.querySelector(".modal-btn");

noticeA.addEventListener("click", () => {
    modal.classList.add("active");
})

modalBtn.addEventListener("click", () => {
    modal.classList.remove("active");
})

let currentSlide = 0;

// 슬라이드 3개
const slide = document.querySelectorAll('.slide')

// 3
const totalSlide = slide.length;

function showSlide(index) {

    const slider = document.querySelector('.slider');
    slider.style.transform = `translateY(${-index * 300}px)`
    // 슬라이더를 세로방향으로 인덱스 곱하기 300만큼 이동
    // -900만큼 이동
}

function nextSlide() {
    currentSlide = (currentSlide + 1) % totalSlide; 
    showSlide(currentSlide);
} setInterval(nextSlide, 3000)
