let slideCount = 0;
const slide = document.querySelectorAll(".slide");
const slider = document.querySelector(".slider");

// setInterval(() => {
//     slideCount = (slideCount + 1) % slide.length;
//     slider.style.transform = `translateX(-${slide[0].clientWidth * slideCount}px)`;
// }, 3000);