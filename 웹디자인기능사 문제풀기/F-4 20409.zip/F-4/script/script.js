let slideCount = 0;
const slider = document.querySelector(".slider")
setInterval(() => {
    slideCount = (slideCount + 1) % 3;
    slider.style.transform = `translateY(-${350 * slideCount}px)`
}, 3000);

const ulList = document.querySelector(".notice-list");
const aList = ulList.getElementsByTagName("a")[0]



const modal = document.querySelector(".modal-container");
const modalBtn = document.querySelector(".modal-btn");

aList.addEventListener("click", () => {
    modal.classList.add("active")
})
modalBtn.addEventListener("click", () => {
    modal.classList.remove("active")
})
