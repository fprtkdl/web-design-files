const slides = document.querySelectorAll(".slide")
let slideCount = 0;

setInterval(() => {
    slides[slideCount].classList.remove("opacity")
    slideCount = (slideCount + 1) % slides.length;
    slides[slideCount].classList.add("opacity")
}, 3000);

const tabTitle = document.querySelectorAll(".tab-title");
const hiddens = document.querySelectorAll(".hiddens"); 

tabTitle.forEach((item, index) => {
    item.addEventListener("click", () => {

        tabTitle.forEach((content) => {
            content.classList.remove("view-title")
        })
        hiddens.forEach((content) => {
            content.classList.remove("view-contents")
        })
        
        tabTitle[index].classList.add("view-title")
        hiddens[index].classList.add("view-contents")

    })
})

const m = document.querySelector(".modal-container");

const qqq = document.querySelector(".qqq");

const www = document.querySelector(".modal-btn");

qqq.addEventListener("click", () => {
    m.classList.add("qwer");
})

www.addEventListener("click", () => {
    m.classList.remove("qwer");
})