const modal = document.querySelector(".modal-container")
const modalClose = document.querySelector(".modal-btn");
const ulList = document.querySelector(".notice");
const aList = ulList.querySelectorAll("a")[0]

aList.addEventListener("click", () => {
    modal.classList.add("activeModal");
})

modalClose.addEventListener("click", () => {
    modal.classList.remove("activeModal");
})

// 슬라이드
let currentSlide = 0;

const slide = document.querySelectorAll('.slide')
const totalSlide = slide.length;

function showSlide(index) {

    const slider = document.querySelector('.slider');
    slider.style.transform = `translateY(${-index * 300}px)`
}

function nextSlide() {
    currentSlide = (currentSlide + 1) % totalSlide; 
    showSlide(currentSlide);
} setInterval(nextSlide, 3000)