const liList = document.querySelector(".notice");
const aList = liList.getElementsByTagName("a")[0];
console.log(aList);

const modal = document.querySelector(".modal-container");
const modalBtn = document.querySelector(".modal-btn")

aList.addEventListener("click", (e) => {
    e.preventDefault();
    modal.classList.add("active")
})

modalBtn.addEventListener("click", (e) => {
    e.preventDefault();
    modal.classList.remove("active")
})

const tabTitle = document.querySelectorAll(".tab-title");
const contents = document.querySelectorAll(".contents");

tabTitle.forEach((item, index) => {
    item.addEventListener("click", (e) => {
        e.preventDefault();

        tabTitle.forEach((content) => {
            content.classList.remove("view-tab");
        })
        contents.forEach((content) => {
            content.classList.remove("view-tab");
        })

        tabTitle[index].classList.add("view-tab");
        contents[index].classList.add("view-tab");
    })
})

let slideCount = 0;
const slider = document.querySelector(".slider");
setInterval(() => {
    slideCount = (slideCount + 1) % 3;
    slider.style.transform = `translateX(-${1440 * slideCount}px)`
}, 3000);