let currentSlide = 0;

const slide = document.querySelectorAll('.slide')
const totalSlide = slide.length;

function showSlide(index) {

    const slider = document.querySelector('.slider');
    slider.style.transform = `translateX(${-index * 1200}px)`
}

function nextSlide() {
    currentSlide = (currentSlide + 1) % totalSlide; 
    showSlide(currentSlide);
} setInterval(nextSlide, 3000)






const notice = document.querySelector(".notice");
const noticeA = notice.querySelectorAll("a")[0]

const modal = document.querySelector(".modal-container");
const modalBtn = document.querySelector(".modal-btn");

noticeA.addEventListener("click", () => {
    modal.classList.add("active");
})

modalBtn.addEventListener("click", () => {
    modal.classList.remove("active");
})