const tabTitle = document.querySelectorAll(".tab-title");
const contents = document.querySelectorAll(".contents");

tabTitle.forEach((item, index) => {
    item.addEventListener("click", (e) => {
        e.preventDefault();

        tabTitle.forEach((content) => {
            content.classList.remove("view-tab");
        })
        contents.forEach((content) => {
            content.classList.remove("view-tab");
        })

        tabTitle[index].classList.add("view-tab");
        contents[index].classList.add("view-tab");
    })
})

// .넣으면 안돼
const modal = document.querySelector(".modal-container")
const modalClose = document.querySelector(".modal-btn");
const ulList = document.querySelector(".notice");
const aList = ulList.querySelectorAll("a")[0]

aList.addEventListener("click", () => {
    modal.classList.add("ononon");
})

modalClose.addEventListener("click", () => {
    modal.classList.remove("ononon");
})

let currentSlide = 0;
const slides = document.querySelectorAll('.slide');
const totalSlides = slides.length;

function showSlide(index) {
    const slider = document.querySelector('.slider');
    slider.style.transform = `translateX(${-index * 1200}px)`;
}

function nextSlide() {
    currentSlide = (currentSlide + 1) % totalSlides; 
    showSlide(currentSlide);
}


setInterval(nextSlide, 3000);