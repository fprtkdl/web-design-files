let slideCount = 0;
const slider = document.querySelector(".slider")
const slide = document.querySelectorAll(".slide")
// setInterval(() => {
//   slideCount = (slideCount + 1) % slide.length;
//   slider.style.transform = `translateX(-${800 * slideCount}px)`
// }, 3000);

setInterval(() => {
  slide[slideCount].classList.remove("active");
  slideCount = (slideCount + 1) % slide.length;
  slide[slideCount].classList.add("active");
}, 3000);







const tabTitle = document.querySelectorAll(".tab-title");
const contents = document.querySelectorAll(".contents")

tabTitle.forEach((item, index) => {
  item.addEventListener("click", (e) => {
    e.preventDefault();
    
    tabTitle.forEach((content) => {
      content.classList.remove("view-tab")
    });
    contents.forEach((content) => {
      content.classList.remove("view-tab")
    });
    tabTitle[index].classList.add("view-tab");
    contents[index].classList.add("view-tab");
  });
});

const ulList = document.querySelector(".notice");
const aList = ulList.getElementsByTagName("a")[0];

aList.addEventListener("click", () => {
  document.querySelector(".modal-container").classList.add("on-modal");
})

document.querySelector(".modal-btn").addEventListener("click", () => {
  document.querySelector(".modal-container").classList.remove("on-modal");
})

